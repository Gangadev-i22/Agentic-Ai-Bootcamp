# 💰 Gold Rate AI Agent

An intelligent Streamlit chatbot that uses:
- 🔎 DuckDuckGo for real-time web search
- 🤖 Gemini 1.5 Flash for language understanding
- 🧠 FAISS & HuggingFace Embeddings for context retrieval

## 🚀 Run It Locally

```bash
git clone https://github.com/yourusername/gold-rate-ai-agent.git
cd gold-rate-ai-agent
pip install -r requirements.txt
streamlit run app.py
```

## 🛡️ Note

Replace the hardcoded Google API Key with a secure method in production (like .env).